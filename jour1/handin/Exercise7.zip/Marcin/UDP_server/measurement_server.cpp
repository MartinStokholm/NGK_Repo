#include "udp_serv.h"

// SHORT AND SWEET :))
int main(void){
    udp_serv server;
}