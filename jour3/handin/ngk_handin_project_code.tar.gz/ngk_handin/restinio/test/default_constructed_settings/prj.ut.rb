require 'mxx_ru/binary_unittest'

Mxx_ru::setup_target(
	Mxx_ru::Binary_unittest_target.new(
		"test/default_constructed_settings/prj.ut.rb",
		"test/default_constructed_settings/prj.rb" )
)
