/*
	restinio
*/

/*!
	Tests for express router engine.
*/

#include <catch2/catch.hpp>

#include <iterator>

#include <restinio/all.hpp>

#include "usings.ipp"

#include "../express/additional_tests.ipp"
