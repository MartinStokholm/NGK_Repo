require 'mxx_ru/binary_unittest'

Mxx_ru::setup_target(
	Mxx_ru::Binary_unittest_target.new(
		"test/write_group_output_ctx/prj.ut.rb",
		"test/write_group_output_ctx/prj.rb" )
)
